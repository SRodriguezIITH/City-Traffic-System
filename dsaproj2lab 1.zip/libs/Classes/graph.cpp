#include "../Headers/graph.h";

Graph::Graph(int vertices) : vertices_(vertices) {
    adjList.resize(vertices);
    adjMat.resize(vertices, vector<pair<int, int>>(vertices, {0, numeric_limits<int>::max()}));

    for (int i = 0; i < vertices; ++i) {
        for (int j = 0; j < vertices; ++j) {
            if (i == j) {
                adjMat[i][j].second = 0;
            }
        }
    }
}

void Graph::addEdge(int u, int v, int weight) {
    adjList[u].emplace_back(v, weight);
    adjList[v].emplace_back(u, weight); 

    adjMat[u][v] = {v, weight};
    adjMat[v][u] = {u, weight}; 
}

vector<int> Graph::dijkstra(int start) {
    vector<int> distances(vertices_, numeric_limits<int>::max());
    distances[start] = 0;

    using PII = pair<int, int>;
    priority_queue<PII, vector<PII>, greater<>> pq;
    pq.emplace(0, start);

    while (!pq.empty()) {
        int dist = pq.top().first;
        int u = pq.top().second;
        pq.pop();

        if (dist > distances[u]) continue;

        for (const auto& [v, weight] : adjList[u]) {
            if (distances[u] + weight < distances[v]) {
                distances[v] = distances[u] + weight;
                pq.emplace(distances[v], v);
            }
        }
    }

    return distances;
}

vector<int> Graph::modifiedDijkstra(int start, int maxWeight) {
    vector<int> distances(vertices_, numeric_limits<int>::max());
    distances[start] = 0;

    using PII = pair<int, int>;
    priority_queue<PII, vector<PII>, greater<>> pq;
    pq.emplace(0, start);

    while (!pq.empty()) {
        int dist = pq.top().first;
        int u = pq.top().second;
        pq.pop();

        if (dist > distances[u]) continue;

        for (const auto& [v, weight] : adjList[u]) {
            if (weight > maxWeight) continue; // Skip edges exceeding max weight
            if (distances[u] + weight < distances[v]) {
                distances[v] = distances[u] + weight;
                pq.emplace(distances[v], v);
            }
        }
    }

    return distances;
}
