#ifndef GRAPH_H
#define GRAPH_H

#include "../../util/libs.cpp";

class Graph {
public:
    Graph(int vertices);
    void addEdge(int u, int v, int weight);
    vector<int> dijkstra(int start);
    vector<int> modifiedDijkstra(int start, int maxWeight);

private:
    int vertices_;
    vector<vector<pair<int, int>>> adjList;
    vector<vector<pair<int, int>>> adjMat;
};

#endif // GRAPH_H
